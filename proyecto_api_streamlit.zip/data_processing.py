import pandas as pd

def clean_data(df: pd.DataFrame) -> pd.DataFrame:
    """Procesa y limpia los datos crudos de la API."""
    df = df.dropna()
    if "fecha" in df.columns:
        df["fecha"] = pd.to_datetime(df["fecha"], errors="coerce")
    return df

def basic_stats(df: pd.DataFrame) -> pd.DataFrame:
    """Devuelve estadísticas descriptivas básicas."""
    return df.describe(include="all")
