import requests
import pandas as pd

def get_data_from_api(url: str) -> pd.DataFrame:
    """Obtiene datos desde la API y los transforma en DataFrame."""
    response = requests.get(url)
    if response.status_code == 200:
        data = response.json()
        df = pd.DataFrame(data)
        return df
    else:
        raise Exception(f"Error en la API: {response.status_code}")
