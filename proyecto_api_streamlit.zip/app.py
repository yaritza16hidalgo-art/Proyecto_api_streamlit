import streamlit as st
import matplotlib.pyplot as plt
from api_client import get_data_from_api
from data_processing import clean_data, basic_stats

# URL de ejemplo (COVID-19 en Chile desde datos.gob.cl)
API_URL = "https://api.covid19api.com/dayone/country/chile"

st.set_page_config(page_title="Análisis de Datos - Chile", layout="wide")

st.title("📊 Análisis de Datos desde API Pública de Chile")

st.sidebar.header("Opciones de filtrado")

try:
    # Obtener datos desde la API
    df = get_data_from_api(API_URL)

    # Procesamiento
    df = clean_data(df)

    # Mostrar primeros datos
    st.subheader("Vista previa de datos")
    st.dataframe(df.head())

    # Estadísticas
    st.subheader("📌 Estadísticas básicas")
    st.write(basic_stats(df))

    # Filtros
    if "Date" in df.columns:
        start_date = st.sidebar.date_input("Fecha inicial", df["Date"].min())
        end_date = st.sidebar.date_input("Fecha final", df["Date"].max())

        mask = (df["Date"] >= str(start_date)) & (df["Date"] <= str(end_date))
        df = df.loc[mask]

    # Gráfico
    if "Confirmed" in df.columns and "Date" in df.columns:
        st.subheader("📈 Evolución de casos confirmados")
        fig, ax = plt.subplots()
        ax.plot(df["Date"], df["Confirmed"], label="Casos confirmados")
        ax.legend()
        st.pyplot(fig)

except Exception as e:
    st.error(f"Error al cargar datos: {e}")
