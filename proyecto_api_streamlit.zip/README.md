# Proyecto: Análisis y presentación de datos utilizando APIs en Python

## Requisitos
Instalar las librerías necesarias:
```
pip install -r requirements.txt
```

## Ejecutar la aplicación
```
streamlit run app.py
```

## Fuente de datos
Los datos provienen de una API pública del Gobierno de Chile:
- https://datos.gob.cl/group
